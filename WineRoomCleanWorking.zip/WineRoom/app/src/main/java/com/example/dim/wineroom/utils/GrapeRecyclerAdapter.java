package com.example.dim.wineroom.utils;

import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.dim.wineroom.MainActivity;
import com.example.dim.wineroom.R;
import com.example.dim.wineroom.data.entities.Grape;

import static com.example.dim.wineroom.MainActivity.ARG_DEBUG;
import static com.example.dim.wineroom.MainActivity.ARG_GRAPE_COUNT;
import static com.example.dim.wineroom.MainActivity.ARG_GRAPE_ITEM;

public class GrapeRecyclerAdapter
        extends RecyclerView.Adapter<GrapeRecyclerAdapter.ViewHolder>
        implements ListFragmentInterface<Grape>{

    private SparseArray<Grape> mValues;
    private View.OnClickListener mOnClickListener;
    private MainActivity parentActivity;

    public GrapeRecyclerAdapter(MainActivity parentActivity, Bundle items) {
        this.parentActivity = parentActivity;
        initMValues(items);

        mOnClickListener = new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (null == view.getTag()) {
                    Log.i(ARG_DEBUG, "onClick: VIEW TAG IS NULL !");
                    return;
                }

                String[] str = view.getTag().toString().split("_");
                if (str[0].isEmpty()) {
                    Log.i(ARG_DEBUG, "onClick: VIEW TAG ACTION IS EMPTY");
                    return;
                }

                if (str[1].isEmpty()) {
                    Log.i(ARG_DEBUG, "onClick: VIEW TAG ITEM IS EMPTY");
                    return;
                }

                int key = (Integer.valueOf(str[1]));
                updateSelectedItem(mValues.get(key));
            }
        };
                //((ListFragmentInterface)items.getSerializable("LISTENER")).onListItemClickListener();
    }

    private void initMValues(Bundle bundle){
        mValues = new SparseArray<>();
        int count = bundle.getInt(ARG_GRAPE_COUNT);
        for (int i = 0; i < count; i++) {
            String arg = ARG_GRAPE_ITEM+String.valueOf(i);
            Grape g = (Grape)bundle.getSerializable(arg);
            //Log.i("DEBUG_RECYCLER", "initMValues: initMValues "+g.toString());
            mValues.put(g.getId(), g);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_grape_item, parent, false);
        //Log.i("DEBUG_RECYCLER", "onCreateViewHolder: passed");
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        int keyAt = mValues.keyAt(position);

        holder.mIdView.setText(String.valueOf(mValues.get(keyAt).getId()));
        holder.mContentView.setText(mValues.get(keyAt).getGrape_label());

        holder.itemLayout.setTag("READ_"+String.valueOf(mValues.get(keyAt).getId()));
        holder.ibtnRemove.setTag("DELETE_"+String.valueOf(mValues.get(keyAt).getId()));
        //holder.ibtnUpdate.setTag("UPDATE_"+String.valueOf(mValues.get(keyAt).getId()));
        holder.ibtnCreate.setTag("CREATE_"+String.valueOf(mValues.get(keyAt).getId()));
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    @Override
    public void updateSelectedItem(Grape selectedItem) {
        parentActivity.updateSelectedItem(selectedItem);
    }
/*
    @Override
    public void addNewItem() {
        parentActivity.addNewItem();
    }
*/
    class ViewHolder extends RecyclerView.ViewHolder {
        final TextView mIdView;
        final TextView mContentView;
        final ConstraintLayout itemLayout;
        final ImageButton ibtnCreate;
        final ImageButton ibtnRemove;
        //final ImageButton ibtnUpdate;

        ViewHolder(View view) {
            super(view);
            // listener for item detail
            itemLayout = (ConstraintLayout) view.findViewById(R.id.li_grape_item_layout);
            itemLayout.setOnClickListener(mOnClickListener);
            // item fields to be populated
            mIdView = (TextView) view.findViewById(R.id.id_text);
            mContentView = (TextView) view.findViewById(R.id.content);
            // create button listener
            ibtnCreate = (ImageButton) view.findViewById(R.id.li_grape_button_add);
            ibtnCreate.setOnClickListener(mOnClickListener);
            // remove button listener
            ibtnRemove = (ImageButton) view.findViewById(R.id.li_grape_button_remove);
            ibtnRemove.setOnClickListener(mOnClickListener);
            // update button listener
            //ibtnUpdate = (ImageButton) view.findViewById(R.id.li_grape_button_edit);
            //ibtnUpdate.setOnClickListener(mOnClickListener);
        }
    }
}
