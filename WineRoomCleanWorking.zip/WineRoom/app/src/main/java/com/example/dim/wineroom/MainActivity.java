package com.example.dim.wineroom;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.SimpleOnPageChangeListener;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.util.SparseArray;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;

import com.example.dim.wineroom.data.ApplicationModel;
import com.example.dim.wineroom.data.entities.Grape;
import com.example.dim.wineroom.fragments.GrapeDetailFragment;
import com.example.dim.wineroom.fragments.GrapeEditFragment;
import com.example.dim.wineroom.fragments.GrapeListFragment;
import com.example.dim.wineroom.fragments.MainFragment;
import com.example.dim.wineroom.utils.DetailFragmentInterface;
import com.example.dim.wineroom.utils.EditFragmentInterface;
import com.example.dim.wineroom.utils.ListFragmentInterface;
import com.example.dim.wineroom.utils.MainSectionPagerAdapter;

public class MainActivity extends AppCompatActivity
        implements ListFragmentInterface<Grape>
        , DetailFragmentInterface<Grape>
        , EditFragmentInterface<Grape>{

    public static final String ARG_GRAPE_ITEM = "GRAPE_ITEM";
    public static final String ARG_GRAPE_COUNT = "GRAPE_COUNT";
    public static final String ARG_GRAPE_SELECTED = "GRAPE_SELECTED";
    public static final String ARG_GRAPE_NEW = "GRAPE_NEW";
    public static final String ARG_DEBUG = "DEBUG";

    private ApplicationModel applicationModel;
    private SparseArray<Grape> grapesModel;
    private Grape selectedGrape;
    private MainSectionPagerAdapter mSectionsPagerAdapter;
    private ViewPager mViewPager;

    private FloatingActionButton add;
    private FloatingActionButton remove;
    private FloatingActionButton sort;
    private FloatingActionButton edit;

    private boolean editMode;
    private boolean detailMode;
    private boolean newMode;

    private MainFragment mainFragment;
    private GrapeListFragment listFragment;
    private GrapeDetailFragment detailFragment;
    private GrapeEditFragment editFragment;

    private SimpleOnPageChangeListener pageChangeListener = new SimpleOnPageChangeListener() {
        @Override
        public void onPageSelected(int position) {
            super.onPageSelected(position);

            if (position == 0) {
                add.hide();
                edit.hide();
                sort.hide();
                remove.hide();
                return;
            }

            if (position == 1) {
                detailMode = false;
                newMode = false;
                edit.hide();
                remove.hide();
                add.show();
                add.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Log.i(ARG_DEBUG, "onClick: CLICK");
                        newMode = true;
                        updateEditFragment(new Grape());
                    }
                });
                sort.show();
                mSectionsPagerAdapter.notifyDataSetChanged();
                return;
            }

            if (detailMode) {
                if (position == 2) {
                    add.hide();
                    sort.hide();
                    remove.show();
                    edit.show();
                    edit.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            //editMode
                            updateEditFragment(selectedGrape);
                        }
                    });
                    editMode = false;
                    mSectionsPagerAdapter.notifyDataSetChanged();
                    return;
                }
            }

            if (newMode) {
                if (position == 2) {
                    add.hide();
                    sort.hide();
                    remove.hide();
                    edit.hide();
                    mSectionsPagerAdapter.notifyDataSetChanged();
                    return;
                }
            }
/*
            if (editMode) {
                if (position == 3) {
                    add.hide();
                    edit.hide();
                    sort.hide();
                    remove.hide();
                    return;
                }
            }*/
        }
    };

    /**
     * @see android.app.Activity#onCreate(android.os.Bundle)
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        applicationModel = new ApplicationModel(getApplicationContext());
        grapesModel = applicationModel.getGrapesModel();
        // Set up the ViewPager with the sections adapter.
        add = (FloatingActionButton) findViewById(R.id.fab_list_add);
        remove = (FloatingActionButton) findViewById(R.id.fab_detail_remove);
        sort = (FloatingActionButton) findViewById(R.id.fab_detail_sort);
        edit = (FloatingActionButton) findViewById(R.id.fab_detail_edit);
        add.hide();
        edit.hide();
        sort.hide();
        remove.hide();

        newMode = false;
        detailMode = false;
        editMode = false;

        mainFragment = MainFragment.newInstance(0);
        listFragment = GrapeListFragment.newInstance(grapesModel);
        detailFragment = GrapeDetailFragment.newInstance();
        editFragment = GrapeEditFragment.newInstance();

        mSectionsPagerAdapter = new MainSectionPagerAdapter(MainActivity.this, getSupportFragmentManager(), applicationModel.getGrapesModel());
        mViewPager = (ViewPager) findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);
        mViewPager.addOnPageChangeListener(pageChangeListener);
    }

    /**
     * @see android.app.Activity#onDestroy()
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        applicationModel.close();
    }

    /**
     * @see android.app.Activity#onCreateOptionsMenu(android.view.Menu)
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    /**
     * @see android.app.Activity#onOptionsItemSelected(android.view.MenuItem)
     */// Returns main page fragment
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {

            return true;
        }

        if (id == android.R.id.home) {

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void updateSelectedItem(Grape selected) {
        selectedGrape = selected;
        Log.i(ARG_DEBUG, "updateSelectedItem: " + selectedGrape.toString());
        updateDetailFragment(selectedGrape);
    }

    @Override
    public void updateDetailFragment(Grape item) {
        detailMode = true;
        mSectionsPagerAdapter.notifyDataSetChanged();
        detailFragment.updateDetailFragment(item);
        mSectionsPagerAdapter.getPage(2);
        mViewPager.setCurrentItem(2);
    }

    @Override
    public void updateEditFragment(Grape item) {
        Log.i(ARG_DEBUG, "updateEditFragment: isNew ? "+newMode);
        if (newMode) {
            mSectionsPagerAdapter.notifyDataSetChanged();
            editFragment.updateEditFragment(new Grape(""));

            mSectionsPagerAdapter.getPage(2);
            mViewPager.setCurrentItem(2);
            return;
        } else {
            editMode = true;
            mSectionsPagerAdapter.notifyDataSetChanged();
            editFragment.updateEditFragment(item);

            mSectionsPagerAdapter.getPage(3);
            mViewPager.setCurrentItem(3);
            return;
        }

    }

    public Grape getSelectedGrape() {
        return selectedGrape;
    }

    public boolean isEditMode() {
        return editMode;
    }

    public boolean isDetailMode() {
        return detailMode;
    }

    public boolean isNewMode() {
        return newMode;
    }

    public SparseArray<Grape> getGrapesModel() {
        return grapesModel;
    }

    public MainFragment getMainFragment() {
        return mainFragment;
    }

    public GrapeListFragment getListFragment() {
        return listFragment;
    }

    public GrapeDetailFragment getDetailFragment() {
        return detailFragment;
    }

    public GrapeEditFragment getEditFragment() {
        return editFragment;
    }
}
