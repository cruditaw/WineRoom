package com.example.dim.wineroom.utils;

public interface EditFragmentInterface<T> {
    public void updateEditFragment(T item);
}
