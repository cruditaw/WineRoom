package com.example.dim.wineroom.utils;

import java.io.Serializable;

public interface ListFragmentInterface<T> extends Serializable
{
    public void updateSelectedItem(T selected);
    //public void addNewItem();
}
