package com.example.dim.wineroom.utils;

public interface DetailFragmentInterface<T> {
    public void updateDetailFragment(T item);
}
